async function simplifyText() {
    const input = document.getElementById("originalText").value;

    if (input.trim() === "") {
        alert("Please enter text first.");
        return;
    }

    try {
        const response = await fetch("http://127.0.0.1:8000/api/simplify", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Accept": "application/json"
            },
            body: JSON.stringify({
                original_text: input
            })
        });

        const data = await response.json();

        if (response.ok) {
            document.getElementById("simplifiedText").innerText = data.simplified_text;
        } else {
            console.log(data);
            alert("Failed to simplify text.");
        }

    } catch (error) {
        console.error(error);
        alert("Server error.");
    }
}